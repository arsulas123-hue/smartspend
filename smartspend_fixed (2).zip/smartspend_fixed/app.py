from flask import Flask, render_template, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, static_folder="static", static_url_path="/static")
app.secret_key = 'supersecretkey'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///smartspend.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ─── Models ──────────────────────────────
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(255))

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))   # ← added user_id
    amount = db.Column(db.Float)
    category = db.Column(db.String(50))
    description = db.Column(db.String(200))

# ─── Routes ──────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    hashed = generate_password_hash(data['password'])
    user = User(email=data['email'], password=hashed)
    db.session.add(user)
    db.session.commit()
    return {"message": "User created"}

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(email=data['email']).first()
    if user and check_password_hash(user.password, data['password']):
        session['user_id'] = user.id
        return {"status": "success"}
    return {"status": "error"}

@app.route('/logout')
def logout():
    session.clear()
    return {"message": "logged out"}

@app.route('/add_transaction', methods=['POST'])
def add_transaction():
    if 'user_id' not in session:
        return {"error": "Not logged in"}

    data = request.json
    tx = Transaction(
        user_id=session['user_id'],
        amount=data['amount'],
        category=data['category'],
        description=data['description']
    )
    db.session.add(tx)
    db.session.commit()
    return {"message": "Saved"}

@app.route('/get_data')
def get_data():
    if 'user_id' not in session:
        return {"error": "Not logged in"}

    txs = Transaction.query.filter_by(user_id=session['user_id']).all()
    data = {}
    for t in txs:
        data[t.category] = data.get(t.category, 0) + t.amount
    return data

@app.route('/predict')
def predict():
    if 'user_id' not in session:
        return {"error": "Not logged in"}

    txs = Transaction.query.filter_by(user_id=session['user_id']).all()
    total = sum(t.amount for t in txs)

    if total > 10000:
        return {"message": "⚠️ You are spending a lot this month!"}
    else:
        return {"message": "✅ Your spending is under control."}

# ─── Entry Point ─────────────────────────
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
