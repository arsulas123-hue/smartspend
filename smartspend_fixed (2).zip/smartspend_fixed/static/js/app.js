fetch('/get_data')
.then(res => res.json())
.then(data => {
  const labels = Object.keys(data);
  const values = Object.values(data);

  new Chart(document.getElementById('myChart'), {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Expenses',
        data: values
      }]
    }
  });
});

fetch('/predict')
.then(res => res.json())
.then(data => {
  alert(data.message);
});